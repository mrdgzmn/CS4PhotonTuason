import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    
    userInfo();
    
  }
}

/*public class Singer {
  String name="Guns N' Roses";
  int noOfPerformances;
  double earnings;
  string favoriteSong;
  
  static void performForAudience() {
    noOfPerformances++;
    
  }
} */