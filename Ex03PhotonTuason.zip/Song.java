public class Song {
  static void songInfo() {
    String songName="I.R.S.";
    String songAlbum="Chinese Democracy";
    String songWriter="Paul Tobias, Dizzy Reed, Axl Rose";
    String songReleaseDate="23 November 2008";
    String songProducers="Axl Rose, Caram Costanzo";
  }
}