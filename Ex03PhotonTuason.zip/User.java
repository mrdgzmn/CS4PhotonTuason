import java.util.Scanner;

public class User {
  
  static void userInfo() {
    Scanner sc = new Scanner(System.in);

    String userDN;
    String username;
    String password;
    String topSong;

    System.out.printf("Welcome to NotIfy! Please enter your user information.%n Username: ");
    username=sc.nextLine();

  }
}